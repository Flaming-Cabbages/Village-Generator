Hi, how are you?

This is the second test version of this program, and therfore I thought I'd put in a readme so that people know what
to do.

So basically, all you have to do to make this work is unzip it (if you didn't already)

You then right click on the powershell script, and click 'Run with Powershell'

A new village will be created and placed in the 'GeneratedVillages' folder.

Inside the 'Configurations' folder are some text documents in which you can change various things.

There is currently only support for 9 family roles, let me know if you need more.