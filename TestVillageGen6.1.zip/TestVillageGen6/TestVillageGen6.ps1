﻿$a = Get-Random -Minimum 1 -Maximum 1000000000000

$curdir = Get-Location

$femalenames = Get-Content "$curdir\Configurations\FemaleNames.txt"
$malenames = Get-Content "$curdir\Configurations\MaleNames.txt"
$occupations = Get-Content "$curdir\Configurations\Occupations.txt"
$elderlyoccupations = Get-Content "$curdir\Configurations\ElderlyOccupations.txt"
$familyroles = Get-Content "$curdir\Configurations\FamilyRoles.txt"
$villagenoraw = Get-Content "$curdir\Configurations\DontTouchThis.txt"
$villageno = [int]$villagenoraw
$malenamecount = $malenames.Length
$femalenamecount = $femalenames.Length
##$carl = $names

$path = "$curdir\GeneratedVillages\New_Village $villageno"

$villageno + 1 | Out-File -FilePath "$curdir\Configurations\DontTouchThis.txt"
##[int]$testno.Length + 2 | Out-File -FilePath "$curdir\Configurations\testno.txt" -Append

$b = New-Item -Path $path -ItemType Directory

$totalpeople = 0
$totalfamilies = 0
$totalmales = 0
$totalfemales = 0
$totalage = 0
$totalold = 0
$totalmid = 0
$totalyoung = 0
$totalmaleworkers = 0
$totalfemaleworkers = 0

$familynum = Get-Random -Minimum 20 -Maximum 50

##Creates a new family
for ($num = 1 ; $num -le $familynum ; $num++){

    $totalfamilies = $num
    $text = "$path\Family_$num"
    $c = New-Item -Path $text -ItemType Directory

    $lastname = Get-Random -Minimum 0 -Maximum $malenamecount

    $peoplenum = Get-Random -Minimum 1 -Maximum 20
    $distributedroles = 0

    $olderagenum = 0
    $middleagenum = 0
    $youngagenum = 0
    ##$oldquant = Get-Random -Minimum 0 -Maximum 4
    ##$midquant = Get-Random -Minimum 1 -Maximum 6
    ##$youngquant = Get-Random -Minimum 0 -Maximum 14

    $oldquant = ($peoplenum/100)*40
    $midquant = ($peoplenum/100)*40
    $youngquant = ($peoplenum/100)*20

    $above16quant = 0

    ##Creates new person
    for ($num2 = 1 ; $num2 -le $peoplenum ; $num2++){

        $totalpeople++
        $malepersonname = Get-Random -Minimum 0 -Maximum $malenamecount
        $femalepersonname = Get-Random -Minimum 0 -Maximum $femalenamecount
        $persongendergen = Get-Random -Minimum 1 -Maximum 20

        if (10 -le $persongendergen){
            $persongender = "Male"
            $totalmales++
            $personname2 = $malenames[$malepersonname] + " " + $malenames[$lastname]
        }

        if (10 -gt $persongendergen){
            $persongender = "Female"
            $totalfemales++
            $personname2 = $femalenames[$femalepersonname] + " " + $malenames[$lastname]
        }

        
        $role = Get-Random -Minimum 1 -Maximum 5
        $role2 = $familyroles[$role]
        $occupation2 = "Too Young!"

        $age = 123456
        
        if($middleagenum -lt $midquant){
            $age = Get-Random -Minimum 18 -Maximum 49
            $middleagenum++
            $totalmid++
        }
        elseif($youngagenum -lt $youngquant){
            $age = Get-Random -Minimum 1 -Maximum 17
            $youngagenum++
            $totalyoung++
        }
        elseif($olderagenum -lt $oldquant){
            $age = Get-Random -Minimum 50 -Maximum 110
            $olderagenum++
            $totalold++
        }        

        if($age -lt 15){

            $age = Get-Random -Minimum 1 -Maximum 14

        }

        if($age -ge 12 -and $age -lt 81){

            $occupationnum = $occupations.Length
            $occupation = Get-Random -Minimum 0 -Maximum $occupationnum
            $occupation2 = $occupations[$occupation]
            if ($persongender -eq "Male"){
                $totalmaleworkers++
            }
            elseif ($persongender -eq "Female"){
                $totalfemaleworkers++
            }

        }
        elseif($age -gt 80){
            $occupationnum = $elderlyoccupations.Length
            $occupation = Get-Random -Minimum 0 -Maximum $occupationnum
            $occupation2 = $elderlyoccupations[$occupation]
            if ($persongender -eq "Male"){
                $totalmaleworkers++
            }
            elseif ($persongender -eq "Female"){
                $totalfemaleworkers++
            }
        }
        
        $totalage = $totalage + $age

"
-----------------------------
Person : $num2
Name : $personname2
Gender : $persongender
Age : 
$age
Occupation : $occupation2
" | Out-File -FilePath "$text\$num2.txt" -Append

}

    ##Creates roles for people
    
    for ($distributedroles = 1 ; $distributedroles -le $peoplenum ; $distributedroles++){

        $rolepath = "$text\$distributedroles.txt"
        $persondata = Get-Content "$rolepath"
        $foundage = [int]$persondata[6]

        ## Checks their age to see if they can have roles
        if($foundage -gt 15){

            $rolenumber = Get-Random -Minimum 1 -Maximum 5

        for ($roles = 1 ; $roles -le $rolenumber ; $roles++){

            ## Assigns roles if able
            if ($foundage -gt 15){

                $who = Get-Random -Minimum 0 -Maximum $peoplenum

                if ($who -eq 0){

                    $who = 1

                }
                
                $selectedroleran = Get-Random -Minimum 1 -Maximum $familyroles.Length
                $selectedrole = $familyroles[$selectedroleran]

                "They are $selectedrole with person $who" | Out-File -FilePath $rolepath -Append

            }
            
            if ($foundage -lt 16){

                $selectedrole = "Too Young!"
                $selectedrole | Out-File -FilePath $rolepath -Append

            }

        }

        }

        "-----------------------------" | Out-File -FilePath $rolepath -Append
       

    }

    for ($added = 1 ; $added -le $peoplenum ; $added++){

        $content = Get-Content "$text\$added.txt"
        $newpath = "$path\Family_$num.txt"
        $content | Out-File -FilePath $newpath -Append
        
        Remove-Item "$text\$added.txt"

    }

    Remove-Item "$path\Family_$num"


}

$averagepersoncount = [math]::Round(($totalpeople)/($totalfamilies),1)
$averageage = [math]::Round(($totalage)/($totalpeople),1)
$averageold = [math]::Round(($totalpeople)/($totalold),1)
$averagemid = [math]::Round(($totalpeople)/($totalmid),1)
$averageyoung = [math]::Round(($totalpeople)/($totalyoung),1)
$totalworkers = $totalmaleworkers + $totalfemaleworkers
$totalnonworkers = $totalpeople - $totalworkers


##Stats for the end of generation
"-----------------Village Stats-----------------
Total Population : $totalpeople
Families : $totalfamilies
Total Female Population : $totalfemales
Total Male Population : $totalmales

-------------------Averages--------------------
Average People Per Family : $averagepersoncount
Average Age : $averageage
Average People Over The Age Of 50 : $averageold
Average People Aged 18-49 : $averagemid
Average People Younger Than 18 : $averageyoung

-------------------Workers--------------------
Total Workers : $totalworkers
Total Working Males : $totalmaleworkers
Total Working Females : $totalfemaleworkers
Total Non-Working : $totalnonworkers

-------------------Totals---------------------
Total Poulation : $totalpeople
Total Families : $totalfamilies
Total Female Population : $totalfemales
Total Male Population : $totalmales
Total People Over The Age Of 50 : $totalold
Total People Aged 18-49 : $totalmid
Total People Younger Than 18 : $totalyoung

Carl : carl
" | Out-File -FilePath $path\Village_Stats.txt -Append

$wshell = New-Object -ComObject Wscript.Shell

$popup = $wshell.Popup("Generated a new village! The village number is $villageno. Open folder?",0,"Village Generated!",0x4)

if ($popup -eq 6){
    ii $path
}