Hi, how are you?

The point of this program is to do bulk generation of people and families for things like D&D.

--- How to run ---

So basically, all you have to do to make this work is unzip it (if you didn't already)

You then right click on the powershell script, and click 'Run with Powershell'

It may ask you to change your policy for running scripts on your computer, just tell it yes.

A new village will be created and placed in the 'GeneratedVillages' folder.

Inside the 'Configurations' folder are some text documents in which you can change various things.

There is currently support for as many family roles as you want, as many occupations as you want, and as many names as you want.

--- More info ---

When you create a new village, it will be a new folder with a bunch of text files in it. Each one of these is a family
If you want more detailed information about the village itself, there will be a file named 'VillageStats', that will have all of the good details.