﻿function GenerateVillage {

## Declare all of the variables
$a = Get-Random -Minimum 1 -Maximum 1000000000000

$curdir = Get-Location

echo "Declaring variables..."
$femalenames = Get-Content "$curdir\Configurations\FemaleNames.txt"
$malenames = Get-Content "$curdir\Configurations\MaleNames.txt"
$occupations = Get-Content "$curdir\Configurations\Occupations.txt"
$elderlyoccupations = Get-Content "$curdir\Configurations\ElderlyOccupations.txt"
$familyroles = Get-Content "$curdir\Configurations\FamilyRoles.txt"
$villagenoraw = Get-Content "$curdir\Configurations\DontTouchThis.txt" ## This will also need to be changed
$settings = Get-Content "$curdir\Configurations\Settings.txt"
$villageno = [int]$villagenoraw
$malenamecount = $malenames.Length
$femalenamecount = $femalenames.Length
echo "Finished declaring variables!"
##$carl = $names

$path = "$curdir\GeneratedVillages\New_Village $villageno"

## Declaring all settings as variables
echo "Fetching settings from file..."
$MinFamilies = $settings[1]
$MaxFamilies = $settings[4]
$MinPPF = $settings[7]
$MaxPPF = $settings[10]
$MinAgeToWork = $settings[13]
$MaxAgeToWork = $settings[16]
$FamilyRoleAmt = $settings[19]
$MinRoleAge = $settings[22]
## Do a simple check to ensure that no maximum numbers are lower than minimum numbers
if($MaxFamilies -le $MinFamilies){
    $MaxFamilies = $MinFamilies + 10
    echo "Maximum families is set to a number less than the minimum families variable! Resolving issue"
}
if($MaxPPF -le $MinPPF){
    $MaxPPF = $MinPPF + 5
    echo "Maximum people per family is set to less than the minimum people per family variable! Resolving issue"
}

echo "Recieved settings from file!"

##Begin running the program to generate a village

$villageno + 1 | Out-File -FilePath "$curdir\Configurations\DontTouchThis.txt" ## this will need to be changed

$b = New-Item -Path $path -ItemType Directory

$totalpeople = 0
$totalfamilies = 0
$totalmales = 0
$totalfemales = 0
$totalage = 0
$totalold = 0
$totalmid = 0
$totalyoung = 0
$totalmaleworkers = 0
$totalfemaleworkers = 0

$familynum = Get-Random -Minimum $MinFamilies -Maximum $MaxFamilies
echo "Set the ammount of families to generate to $familynum"

##Creates a new family
for ($num = 1 ; $num -le $familynum ; $num++){

    echo "Beginning to generate a new family..."
    $totalfamilies = $num
    $text = "$path\Family_$num"
    $c = New-Item -Path $text -ItemType Directory

    $lastname = Get-Random -Minimum 0 -Maximum $malenamecount
    echo "Set last name to $lastname"

    $peoplenum = Get-Random -Minimum $MinPPF -Maximum $MaxPPF
    echo "Set total people in family count to $peoplenum"
    $distributedroles = 0

    $olderagenum = 0
    $middleagenum = 0
    $youngagenum = 0

    $oldquant = ($peoplenum/100)*40
    $midquant = ($peoplenum/100)*40
    $youngquant = ($peoplenum/100)*20

    $above16quant = 0

    echo "Preparing to create new people..."
    ##Creates new person
    for ($num2 = 1 ; $num2 -le $peoplenum ; $num2++){

        $totalpeople++
        $malepersonname = Get-Random -Minimum 0 -Maximum $malenamecount
        $femalepersonname = Get-Random -Minimum 0 -Maximum $femalenamecount
        $persongendergen = Get-Random -Minimum 1 -Maximum 20
        echo "Created a new person"

        if (10 -le $persongendergen){
            $persongender = "Male"
            $totalmales++
            echo "Assigned gender 'Male' to the new person"
            $personname2 = $malenames[$malepersonname] + " " + $malenames[$lastname]
            echo "Assigened name to new person, F: $malepersonname  L: $lastname"
        }

        if (10 -gt $persongendergen){
            $persongender = "Female"
            $totalfemales++
            echo "Assigned gender 'Female' to the new person"
            $personname2 = $femalenames[$femalepersonname] + " " + $malenames[$lastname]
            echo "Assigened name to new person, F: $malepersonname  L: $lastname"
        }
        echo "Successfully assigned name and gender to new person"
        
        $role = Get-Random -Minimum 1 -Maximum $familyroles.Length
        $role2 = $familyroles[$role]
        $occupation2 = "Too Young!"
        echo "Beginning to assign age to new person"

        $age = 123456
        
        if($middleagenum -lt $midquant){
            $age = Get-Random -Minimum 18 -Maximum 49
            $middleagenum++
            $totalmid++
            echo "Assigned age $age to new person"
        }
        elseif($youngagenum -lt $youngquant){
            $age = Get-Random -Minimum 1 -Maximum 17
            $youngagenum++
            $totalyoung++
            echo "Assigned age $age to new person"
        }
        elseif($olderagenum -lt $oldquant){
            $age = Get-Random -Minimum 50 -Maximum 110
            $olderagenum++
            $totalold++
            echo "Assigned age $age to new person"
        }        

        if($age -lt 15){

            $age = Get-Random -Minimum 1 -Maximum 14
            echo "Age was less than 15, rerolling one time..."

        }

        if($age -ge $MinAgeToWork -and $age -lt $MaxAgeToWork + 1){

            echo "Person is the right age to work, assigning occupation"
            $occupationnum = $occupations.Length
            $occupation = Get-Random -Minimum 0 -Maximum $occupationnum
            $occupation2 = $occupations[$occupation]
            echo "Assigned occupation $occupation to new person"
            if ($persongender -eq "Male"){
                $totalmaleworkers++
            }
            elseif ($persongender -eq "Female"){
                $totalfemaleworkers++
            }

        }
        elseif($age -gt $MaxAgeToWork){
            echo "Person is over the age of $MaxAgeToWork, assigning a elderly occupation"
            $occupationnum = $elderlyoccupations.Length
            $occupation = Get-Random -Minimum 1 -Maximum $occupationnum
            $occupation2 = $elderlyoccupations[$occupation]
            if ($persongender -eq "Male"){
                $totalmaleworkers++
            }
            elseif ($persongender -eq "Female"){
                $totalfemaleworkers++
            }
        }
        
        echo "Finished creating person!"
        $totalage = $totalage + $age

"
-----------------------------
Person : $num2
Name : $personname2
Gender : $persongender
Age : 
$age
Occupation : $occupation2
" | Out-File -FilePath "$text\$num2.txt" -Append

}

    ##Creates roles for people
    echo "Finished creating people, beginning to assign family roles"
    for ($distributedroles = 1 ; $distributedroles -le $peoplenum ; $distributedroles++){

        $rolepath = "$text\$distributedroles.txt"
        $persondata = Get-Content "$rolepath"
        $foundage = [int]$persondata[6]

        ## Checks their age to see if they can have roles
        if($foundage -gt 15){

            $rolenumber = Get-Random -Minimum 1 -Maximum 5
            echo "Person is old enough to have family roles, they will have $rolenumber family roles"

        for ($roles = 1 ; $roles -le $rolenumber ; $roles++){

            ## Assigns roles if able
            if ($foundage -gt $MinRoleAge - 1){

                $who = Get-Random -Minimum 0 -Maximum $peoplenum

                if ($who -eq 0){

                    $who = 1

                }
                
                $selectedroleran = Get-Random -Minimum 1 -Maximum $familyroles.Length
                $selectedrole = $familyroles[$selectedroleran]

                "They are $selectedrole with person $who" | Out-File -FilePath $rolepath -Append
                echo "Sucessfully assigned roles to person!"

            }
            
            if ($foundage -lt $MinRoleAge){

                echo "Person is too young to have any family roles"
                $selectedrole = "Too Young!"
                $selectedrole | Out-File -FilePath $rolepath -Append

            }

        }

        }

        "-----------------------------" | Out-File -FilePath $rolepath -Append
        echo "Finished assigning roles to person!"
       

    }

    for ($added = 1 ; $added -le $peoplenum ; $added++){

        echo "Compiling all of the info into one area..."
        $content = Get-Content "$text\$added.txt"
        $newpath = "$path\Family_$num.txt"
        $content | Out-File -FilePath $newpath -Append
        
        Remove-Item "$text\$added.txt"

    }

    echo "Finished compiling!"
    Remove-Item "$path\Family_$num"


}

$averagepersoncount = [math]::Round(($totalpeople)/($totalfamilies),1)
$averageage = [math]::Round(($totalage)/($totalpeople),1)
$averageold = [math]::Round(($totalpeople)/($totalold),1)
$averagemid = [math]::Round(($totalpeople)/($totalmid),1)
$averageyoung = [math]::Round(($totalpeople)/($totalyoung),1)
$totalworkers = $totalmaleworkers + $totalfemaleworkers
$totalnonworkers = $totalpeople - $totalworkers
echo "Calculated averages for the total file"


##Stats for the end of generation
"-----------------Village Stats-----------------
Total Population : $totalpeople
Families : $totalfamilies
Total Female Population : $totalfemales
Total Male Population : $totalmales

-------------------Averages--------------------
Average People Per Family : $averagepersoncount
Average Age : $averageage
Average People Over The Age Of 50 : $averageold
Average People Aged 18-49 : $averagemid
Average People Younger Than 18 : $averageyoung

-------------------Workers--------------------
Total Workers : $totalworkers
Total Working Males : $totalmaleworkers
Total Working Females : $totalfemaleworkers
Total Non-Working : $totalnonworkers

-------------------Totals---------------------
Total Poulation : $totalpeople
Total Families : $totalfamilies
Total Female Population : $totalfemales
Total Male Population : $totalmales
Total People Over The Age Of 50 : $totalold
Total People Aged 18-49 : $totalmid
Total People Younger Than 18 : $totalyoung

Carl : carl
" | Out-File -FilePath $path\Village_Stats.txt -Append
echo "Generated and output all of the information!"

$wshell = New-Object -ComObject Wscript.Shell

$popup = $wshell.Popup("Generated a new village! The village number is $villageno. Open folder?",0,"Village Generated!",0x4)

if ($popup -eq 6){
    ii $path
}
}

## The section below is the settings editor

$location = Get-Location
$wshell = New-Object -ComObject wscript.shell;

Function RunAll{
    Clear-Host
    echo "To run the program, type 'R', to enter settings, type 'S', to open the changelog, type 'C'. To exit type 'E'"

    $input = Read-Host -Prompt "Option"
    $changelog = Get-Content "$location\CHANGELOG.txt"

    function Run-Settings{
        $content = Get-Content "$location\Configurations\Settings.txt"
        $settingspath = "$location\Configurations\Settings.txt"
        $setting1 = $content[1]
        $settingName1 = $content[0]
        $setting2 = $content[4]
        $settingName2 = $content[3]
        $setting3 = $content[7]
        $settingName3 = $content[6]
        $setting4 = $content[10]
        $settingName4 = $content[9]
        $setting5 = $content[13]
        $settingName5 = $content[12]
        $setting6 = $content[16]
        $settingName6 = $content[15]
        $setting7 = $content[19]
        $settingName7 = $content[18]
        $setting8 = $content[22]
        $settingName8 = $content[21]

        Function UpdateSetting{
            Param ($settingtochange, $settingtochangevalue)
            $updatedcontent = Get-Content "$location\Configurations\Settings.txt"
            ##Clear-Host
            $settingstext2 = "
            ---- SETTINGS ----

            Please type a new value for $settingtochange    
            "
            echo $settingstext2
            $input = Read-Host -Prompt "Enter New Value"

            $updatedcontent[$settingtochangevalue] = $updatedcontent[$settingtochangevalue] -replace $updatedcontent[$settingtochangevalue], $input
            Set-Content -Path $settingspath -Value $updatedcontent
            echo "Updated settings!"
            Run-Settings
        
        }
        Clear-Host
    

        $settingstext = "
        ---- SETTINGS ----                
                                          
        [[1]] $settingName1 : $setting1   
        [[2]] $settingName2 : $setting2   
        [[3]] $settingName3 : $setting3
        [[4]] $settingName4 : $setting4   
        [[5]] $settingName5 : $setting5
        [[6]] $settingName6 : $setting6
        [[7]] $settingName7 : $setting7
        [[8]] $settingName8 : $setting8

        [[20]] Open the Male Names File
        [[21]] Open the Female Names File
        [[22]] Open the Family Roles File
        [[23]] Open the Occupations File
        [[24]] Open the Elderly Occupations File
                                          
        ---- Press the coresponding number to the setting you wish to change or type 'E' to exit ----
        "
        echo $settingstext
        $input = Read-Host -Prompt "Option"
    
        ## Open the setting editor
        if($input -ieq "1"){
            UpdateSetting $settingName1 1
        }
        elseif($input -ieq "2"){
            UpdateSetting $settingName2 4
        }
        elseif($input -ieq "3"){
            UpdateSetting $settingName3 7
        }
        elseif($input -ieq "4"){
            UpdateSetting $settingName4 10
        }
        elseif($input -ieq "5"){
            UpdateSetting $settingName5 13
        }
        elseif($input -ieq "6"){
            UpdateSetting $settingName6 16
        }
        elseif($input -ieq "7"){
            UpdateSetting $settingName7 19
        }
        elseif($input -ieq "8"){
            UpdateSetting $settingName8 22
        }
        ## Ones to open files instead of editor
        elseif($input -ieq "20"){
            ii -Path "$location\Configurations\MaleNames.txt"
            Run-Settings
        }
        elseif($input -ieq "21"){
            ii -Path "$location\Configurations\FemaleNames.txt"
            Run-Settings
        }
        elseif($input -ieq "22"){
            ii -Path "$location\Configurations\FamilyRoles.txt"
            Run-Settings
        }
        elseif($input -ieq "23"){
            ii -Path "$location\Configurations\Occupations.txt"
            Run-Settings
        }
        elseif($input -ieq "24"){
            ii -Path "$location\Configurations\ElderlyOccupations.txt"
            Run-Settings
        }
        elseif($input -ieq "e"){
            RunAll
        }
        else{
            echo "Invalid input! Please try again"
            Sleep 2
            Run-Settings
        }
    }
    Function Run-Program{
        GenerateVillage
    }
    ## End of functions ##
    if ($input -ieq "s"){
        Run-Settings
    }
    elseif($input -ieq "r"){
        Run-Program
    }
    elseif($input -ieq "e"){
        Closedown
    }
    elseif($input -ieq "c"){
        ii -Path "$location\CHANGELOG.txt"
        RunAll
    }
    else{
        echo "Invalid input!"
        Sleep 2
        RunAll
    }
}
Function Closedown{
    echo "Closing Program, Please Wait..."
    Sleep 2
    Break
}
RunAll