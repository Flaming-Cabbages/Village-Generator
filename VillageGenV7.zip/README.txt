Hi, how are you?

The point of this program is to do bulk generation of people and families for things like D&D.

--- How to run ---

So basically, all you have to do to make this work is unzip it (if you didn't already)

You then double-click on the batch file named "RunMe", you do not need to run as admin.

DO NOT RUN THE BATCH FILE AS ADMINISTRATOR, THE PROGRAM WILL MALFUNCTION AND NOT WORK

A new village will be created and placed in the 'GeneratedVillages' folder.

There is currently support for as many family roles as you want, as many occupations as you want, and as many names as you want.

--- More info ---

When you create a new village, it will be a new folder with a bunch of text files in it. Each one of these is a family
If you want more detailed information about the village itself, there will be a file named 'VillageStats', that will have all of the good details.

You will see that there is a file named "donttouchthis" the number contained in this file is the number that will be put on the end of new villages,
if you change this so that it is no longer a number, the program will probably break. Also don't add any text to the file, it won't go well.



Hope this helps you out,

-Flaming Cabbages